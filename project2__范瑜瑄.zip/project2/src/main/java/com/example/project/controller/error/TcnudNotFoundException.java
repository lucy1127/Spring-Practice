package com.example.project.controller.error;

public class TcnudNotFoundException extends RuntimeException{
    
}
