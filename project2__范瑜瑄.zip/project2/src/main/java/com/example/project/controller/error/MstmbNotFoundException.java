package com.example.project.controller.error;

public class MstmbNotFoundException extends RuntimeException {
    
}
